const cards = document.querySelectorAll('.plate');

// Hide all cards

cards.forEach(function(card) {
    card.classList.add('none')
})



let currentIndex = 0 // For roadway by cards

let currentCard = 0 // For roadway progress bar with procent



// Hide btn 'Prev' on first card

cards[0].querySelector('[data-nav="prev"]').remove();


// Show first card
cards[currentIndex].classList.remove('none');
cards[currentIndex].classList.add('visible');

// Run progress Bar (green line) with procent 

updateProgressBar();


window.addEventListener('click', function(event){
    
    // Movement forward
    if (event.target.closest('[data-nav="next"]')) {
        console.log('Next!');
        
        const result = checkOnAnswer(cards[currentIndex]);
        const answersWrapper = cards[currentIndex].querySelector('[data-answers]');

        if (result) {

            // Progress bar with procent
            updateProgressBar('next');


            // moving green bar

            setTimeout (function(){

                
                // hide current card with animation
                cards[currentIndex].classList.remove('visible');
                
                
                setTimeout(function(){
                    // hide current card completly
                    cards[currentIndex].classList.add('none');
                    
                    // Showing the next card and prepare to animation
                    // Hide current card
                    currentIndex = currentIndex + 1;
                    cards[currentIndex].classList.remove('none');

                    setTimeout(function(){
                        // showing the next with animation
                        cards[currentIndex].classList.add('visible');

                    }, 100)

                }, 500);

                // Show next card
    
                // answersWrapper.classList.remove('required');



            }, 500)

        } else {
            console.error('Enter answer!!!');

            answersWrapper.classList.add('required');

        }

    }

    // if (currentIndex === cards.length - 1) {
    //     return;
    // }

    

    // Movement backward

    if (event.target.closest('[data-nav="prev"]')) {
        console.log('Prev!');


        // Progress bar with procent
        updateProgressBar('prev');

        setTimeout (function(){
            //Moving between cards
        if (currentIndex === 0) {
            return;
        }
        cards[currentIndex].classList.remove('visible');

        setTimeout(function(){
            cards[currentIndex].classList.remove('none');
            
            // find prev card and prepare it to animation
            currentIndex = currentIndex - 1;


            cards[currentIndex].classList.remove('none');

            // showing the prev card with animation
            setTimeout(function() {
                cards[currentIndex].classList.add('visible');

            }, 100)

        }, 500)
        
        
        

        // Show prev card
        }, 500)
        
        
    }

})

function checkOnAnswer (card) {
    
    
    console.log(card);
    
    // chech radiobtns
    
    const radioBtns = card.querySelectorAll('input[type="radio"]');
    
    if (radioBtns.length > 0) {
        for (let radio of radioBtns) {
            if (radio.checked) {
            return true;
            }
        }
    }

    // check on checkBoxes

    const checkBoxes = card.querySelectorAll('input[type="checkbox"]');

    if (checkBoxes.length > 0) {
        for (let checkbox of checkBoxes) {
            if (checkbox.checked) {
                return true;
            }
        }
    }

}


function updateProgressBar (direction = 'start') {


    if (direction === 'next') {
        currentCard = currentCard + 1;
    } else if (direction === 'prev') {
        currentCard = currentCard - 1;
    }
    


    const progressValue = document.querySelectorAll('.progress__label strong');
    console.log(progressValue);

    const progressLineBar = document.querySelectorAll('.progress__line-bar');
    console.log(progressLineBar);


    const countableCards = document.querySelectorAll('[data-progress]').length;
    console.log(countableCards);

    const progress = Math.round((currentCard * 100) / countableCards);
    console.log(progress);


    progressValue.forEach(function(item) {
        item.innerText = progress + '%';
    })
    
    

    progressLineBar.forEach(function(item) {
        item.style.width = progress + '%';
    })
}


// Phone mask 

mask('#tel');

const submitForm = document.querySelector('#submitForm');

const telInput = document.querySelector('#tel')

submitForm.onclick = function() {
    if(telInput.value === '+' || telInput.value.length < 6) {
        telInput.value = ''
    }
}

// Focus on checkbox and styling frame around it

const checkBoxPolicy = document.querySelector('#policy'); 

checkBoxPolicy.addEventListener('focus', function (){
    console.log('Focus');
    this.closest('label').classList.add('hovered');
})


checkBoxPolicy.addEventListener('blur', function(){
    console.log('Blur');
    this.closest('label').classList.remove('hovered');
})